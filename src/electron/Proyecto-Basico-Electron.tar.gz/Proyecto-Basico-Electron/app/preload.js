window.ipcRendererer = require('electron').ipcRenderer;
